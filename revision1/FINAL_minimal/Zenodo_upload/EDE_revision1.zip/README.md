# EDE revision one minimal replication archive

This archive contains only the corrected code and numerical evidence needed to
rerun the revision experiments and the descriptive Yandex logged-support
replay. It excludes manuscript files, figure and table upload assets, the
separate `utils` repository, raw Yandex logs, and paper-specific builders.

From the archive root, install the tested dependencies and run the focused
tests:

```text
python -m pip install -r revision1/requirements-revision.txt
python -m pytest tests -q
```

The complete corrected synthetic experiment suite can be rerun with:

```text
python -m src.ede_sanity.revision_experiments --workers 4
```

The optional logged-support replay requires the author's own Kaggle access:

```text
python revision1/fetch_replay_data.py
python -m src.ede_real_replay.revision_replay --log revision1/data/train_first_200000_sessions.txt
```

The acquisition script saves the first 200,000 complete sessions and a
SHA-256 source manifest; the raw log is not redistributed. The included
results were produced with validation seeds 100-109 and held-out seeds
1000-1019. The frozen operating point is lambda=0.4, eta=0.65, m=2,
top_L=50, alpha=0.5, and tau=50. The replay uses 2,000 session bootstrap
resamples with seed 20260911 and is a descriptive ten-candidate
logged-support diagnostic, not causal engagement or cold-start evidence.

`SHA256.json` records the SHA-256 hash of every archived file other than the
manifest itself.
