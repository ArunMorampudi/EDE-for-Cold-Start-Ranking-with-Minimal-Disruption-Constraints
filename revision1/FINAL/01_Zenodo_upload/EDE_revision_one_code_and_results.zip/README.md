# EDE revision one code and numerical results

These corrected results supersede the original simulation and replay estimates.
The archive contains code, tests, dependencies, per-seed results and source-selection
metadata. Raw Yandex logs and peer-review correspondence are excluded.

Run these commands from this archive root with Python 3.12:

```
python -m pip install -r revision1/requirements-revision.txt
python -m pytest tests -q
python -m src.ede_sanity.revision_experiments --workers 4
python revision1/fetch_replay_data.py
python -m src.ede_real_replay.revision_replay --log revision1/data/train_first_200000_sessions.txt
python revision1/build_figures_tables.py
```

The acquisition script requires your own Kaggle credentials and access to the
Yandex Personalized Web Search Challenge. The saved source manifest specifies the
first 200,000 complete training sessions and their SHA-256 hash. These yield
372,282 separate result pages; this is not the historical 61,105-session sample.

Validation uses seeds 100–109; held-out tests use 1000–1019. Lambda is selected
on validation data and frozen for the test conditions. The 100 validation and
3,900 test runs, full summary statistics and protocol are included.

The corrected policy preserves the original prefix before novelty gating and
retains the same penalized base score in both policies. The replay maps clicks
by page and document and updates only actual logged events. Set/click preservation
is structural on ten logged candidates, not evidence of causal engagement or
real-world cold-start discovery. Comparators include explicitly defined heuristics,
not exact reproductions of full published safe-ranking algorithms.

Figure/table regeneration uses saved result CSVs and writes separate files to
submitted_peerj_docs. It does not regenerate or rewrite the manuscript.
